/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author acer
 */
public class objek {

    String namaobjek;
    String[] gejalaobjek;

    public objek(String nama, String[] gejala) {
        this.namaobjek = nama;
        this.gejalaobjek = gejala;
    }
}
