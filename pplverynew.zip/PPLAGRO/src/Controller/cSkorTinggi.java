/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import View.vPetunjuk;
import View.vSkorTinggi;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.koneksi;

/**
 *
 * @author DWI WAHYU
 */
public class cSkorTinggi {

    vSkorTinggi view;
    koneksi model;

    public cSkorTinggi() throws SQLException {
        this.view = new vSkorTinggi();
        view.getBtnOk().addActionListener(new OkAction());
        this.model = new koneksi();

        view.setSkor(model.getDataSkorTinggi());
    }

    private class OkAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                new cHalamanAwal().showPage(true);
            } catch (SQLException ex) {
                Logger.getLogger(cSkorTinggi.class.getName()).log(Level.SEVERE, null, ex);
            }

            view.dispose();
        }
    }

    public void showPage(boolean status) {
        view.setVisible(status);
    }
}
