package Controller;

import View.vHalamanMain;
import java.awt.datatransfer.Transferable;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.TransferHandler;

public class cHalamanMain {

    private vHalamanMain view;
    private ImageIcon PasienNull, DropBox;
    private int waktuJalan;
    private mulaiPermainan game;
    private ImageIcon[][] pasienIcon;

    public cHalamanMain() {
        this.view = new vHalamanMain();
        this.game = new mulaiPermainan();
        //Deklarasi icon
        this.PasienNull = new ImageIcon(getClass().getResource("/img/150150null.png"));
        this.DropBox = new ImageIcon(getClass().getResource("/img/kotak.png"));
        String namaPasien = "";
        pasienIcon = new ImageIcon[5][3];
        for (int i = 0; i < 5; i++) { //i jenis
            switch (i) {
                case 0:
                    namaPasien = "apel";
                    break;
                case 1:
                    namaPasien = "jeruk";
                    break;
                case 2:
                    namaPasien = "kakao";
                    break;
                case 3:
                    namaPasien = "kelapa sawit";
                    break;
                case 4:
                    namaPasien = "kopi";
                    break;
            }
            for (int j = 0; j < 3; j++) { //level 
                //System.out.println(namaPasien);
                this.pasienIcon[i][j] = new ImageIcon(getClass().getResource("/img/" + namaPasien + " level " + (j + 1) + ".png"));
            }
        }
        //Seticon default
        view.getImgPasienDokter().setIcon(DropBox);
        view.getImgPasienApotek().setIcon(DropBox);
        view.getImgPasienFrame1().setIcon(PasienNull);
        view.getImgPasienFrame2().setIcon(PasienNull);
        //view.getImgPasienFrame2().setIcon(pasienIcon[1][0]);
        //thread
        try {
            //showPage(true);
            this.game.start();

            MouseListener ml = new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {

                }

                @Override
                public void mousePressed(MouseEvent e) {
                    JComponent jc = (JComponent) e.getSource();
                    TransferHandler th = jc.getTransferHandler();

                    th.exportAsDrag(jc, e, TransferHandler.MOVE);
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                }

                @Override
                public void mouseExited(MouseEvent e) {
                }
            };
            //Add action listener
            view.getImgPasienFrame1().addMouseListener(ml);
            view.getImgPasienFrame2().addMouseListener(ml);
            view.getImgPasienDokter().addMouseListener(ml);
            view.getImgPasienApotek().addMouseListener(ml);
            
            
            
            //transferhandler
            view.getImgPasienFrame1().setTransferHandler(new TransferHandler("icon") {
                @Override
                protected void exportDone(JComponent source, Transferable data, int action) {
                    if (action == MOVE) {
                        ((JLabel) source).setIcon(PasienNull);//Default
                    }
                }

                @Override
                public boolean canImport(TransferHandler.TransferSupport support) {
                    if (!view.getImgPasienFrame1().getIcon().equals(PasienNull)) {
                        return false;
                    }

                    return true;
                }

                @Override
                public int getSourceActions(JComponent c) {
                    if (!view.getImgPasienFrame1().getIcon().equals(PasienNull)) {
                        return COPY | MOVE;
                    } else {
                        return NONE;
                    }
                }
            });
            view.getImgPasienFrame2().setTransferHandler(new TransferHandler("icon") {
                @Override
                protected void exportDone(JComponent source, Transferable data, int action) {
                    if (action == MOVE) {
                        ((JLabel) source).setIcon(PasienNull);//Default
                    }
                }

                @Override
                public boolean canImport(TransferHandler.TransferSupport support) {
                    if (!view.getImgPasienFrame2().getIcon().equals(PasienNull)) {
                        return false;
                    }

                    return true;
                }

                @Override
                public int getSourceActions(JComponent c) {
                    if (!view.getImgPasienFrame2().getIcon().equals(PasienNull)) {
                        return COPY | MOVE;
                    } else {
                        return NONE;
                    }
                }
            });
            view.getImgPasienDokter().setTransferHandler(new TransferHandler("icon") {
                @Override
                protected void exportDone(JComponent source, Transferable data, int action) {

                    if (action == MOVE) {
                        ((JLabel) source).setIcon(DropBox);//Default
                    }

                }

                @Override
                public boolean canImport(TransferHandler.TransferSupport support) {
                    if (!view.getImgPasienDokter().getIcon().equals(DropBox)) {
                        return false;
                    }

                    return true;
                }

                @Override
                public int getSourceActions(JComponent c) {
                    if (!view.getImgPasienDokter().getIcon().equals(DropBox)) {
                        return COPY | MOVE;
                    } else {
                        return NONE;
                    }
                }
            });
            view.getImgPasienApotek().setTransferHandler(new TransferHandler("icon") {
                @Override
                protected void exportDone(JComponent source, Transferable data, int action) {
                    if (action == MOVE) {
                        ((JLabel) source).setIcon(DropBox);//Default
                    }
                }

                @Override
                public boolean canImport(TransferHandler.TransferSupport support) {
                    if (!view.getImgPasienApotek().getIcon().equals(DropBox)) {
                        return false;
                    }

                    return true;
                }

                @Override
                public int getSourceActions(JComponent c) {
                    if (!view.getImgPasienApotek().getIcon().equals(DropBox)) {
                        return COPY | MOVE;
                    } else {
                        return NONE;
                    }
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
    }

    public vHalamanMain getView() {
        return view;
    }

    private boolean isKosong(JLabel img) {
        if (img.getIcon().equals(PasienNull) || img.getIcon().equals(DropBox)) {
            return true;
        } else {
            return false;
        }
    }

    public void showPage(boolean status) {
        view.setVisible(status);
    }

    private class mulaiPermainan extends Thread {

        int moduloSpawnPasien, pasienIdx, pasienLvl;
        Random random;
        boolean adaPopup;
                
        public mulaiPermainan() {
            waktuJalan = 1;
            random = new Random();
            adaPopup = false;
        }

        public void run() {
            //showPage(true);
            while (true) {
                waktuJalan++;
                //System.out.println(waktuJalan);
                moduloSpawnPasien = random.nextInt(3) + 10;
                if (waktuJalan % moduloSpawnPasien == 0) {
                    if (isKosong(view.getImgPasienFrame1())) { //kalau yg kursi 1 kosong
                        pasienIdx = random.nextInt(5);
                        pasienLvl = 0;
                        view.getImgPasienFrame1().setIcon(pasienIcon[pasienIdx][pasienLvl]);
                    } else if (isKosong(view.getImgPasienFrame2())) { //kalau yg kursi 2 kosong
                        pasienIdx = random.nextInt(5);
                        pasienLvl = 0;
                        view.getImgPasienFrame2().setIcon(pasienIcon[pasienIdx][pasienLvl]);
                    }
                }
                
                if (!adaPopup) {
                    if (!isKosong(view.getImgPasienApotek())) {
                        //lek apotek onok isine
                        adaPopup = true;
                        System.out.println("Apotek onok isine");
                    }else if(!isKosong(view.getImgPasienDokter())){
                        //lek dokter onok koncone
                        adaPopup = true;
                        view.setEnabled(false);
                        new cHalamanDokter(cHalamanMain.this).showPage(true);
                    }else{
                    //lek apotek karo dokter carok
                    }
                }
                
                try {
                    sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(cHalamanMain.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

}
