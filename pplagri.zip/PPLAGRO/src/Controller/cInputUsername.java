/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import View.vInputUsername;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author DWI WAHYU
 */
public class cInputUsername {

    vInputUsername view;

    public cInputUsername() {
        this.view = new vInputUsername();
        view.getBtnOk().addActionListener(new OkAction());

    }

    private class OkAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (!view.getUsername().getText().isEmpty()) {
                new cHalamanMain().showPage(true);
                view.dispose();
            }
            else{
                JOptionPane.showMessageDialog(view, "Username tidak boleh kosong!","Peringatan!",JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    public void showPage(boolean status) {
        view.setVisible(status);
    }

}
