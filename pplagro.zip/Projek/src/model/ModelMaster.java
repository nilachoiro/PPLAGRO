/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author nila
 */
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public abstract class ModelMaster {

    koneksi con;

    public ModelMaster() throws SQLException {
        con = new koneksi(); //membuat objek koneksi baru dari kelas koneksi.
    }

    public String[] getDataID(String query, String data[]) throws SQLException {

        ResultSet rs = con.getResult(query);
        if (rs.next()) { // Jika Data dengan ID tersebut Ditemukan.
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1); //memasukkan data yg diperoleh kedalam array
            }
        }
        return data;
    }

    public boolean execute(String query){
    boolean succesInput;
        try {
            con.executeQuery(query);
            succesInput = true;
            System.out.println("yeay berhasil query");
        } catch (SQLException ex) {
            System.out.println("gagal loh querynya");
            succesInput = false;
        }
        return succesInput;
    }
     public DefaultTableModel getDatatotal(String kolom[],String query) throws SQLException {
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        ResultSet rs = con.getResult(query);

        while (rs.next()) {
            String row[] = new String[kolom.length];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1);
            }
            table.addRow(row);
        }

        return table;
    }

    public abstract DefaultTableModel getData() throws SQLException;

    public abstract String[] getDataWithID(String ID) throws SQLException;

    public abstract boolean insertData(String data[]);

    public abstract boolean updateData(String data[]);

    public abstract boolean deleteData(String ID);

}
