/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author nila
 */
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class Madmin_petugas extends ModelMaster {

    koneksi con;

    public Madmin_petugas() throws SQLException {
        con = new koneksi(); //membuat objek koneksi baru dari kelas koneksi.
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"id_petugas", "id_akun","nama_petugas","no_HP", "alamat","password","jabatan"};
        String query = "select id_petugas,p.id_akun,nama_petugas,no_HP,alamat,password,jabatan from petugas p join akun a on(p.id_akun=a.id_akun) ;";
        return getDatatotal(kolom, query);
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[7];
        String query = "select id_petugas,p.id_akun,nama_petugas,no_HP,alamat,password,jabatan from petugas p join akun a on(p.id_akun=a.id_akun)where id_petugas = " + ID + ";";

        return getDataID(query, data);
    }

    @Override
    public boolean insertData(String data[]) {

        String query = "insert into petugas(nama_petugas,no_HP,alamat,id_akun) values('" + data[2] + "'," + data[3] + ",'" + data[4] + "',(select MAX(id_akun) from akun order by id_akun ASC))";
        String query2 = "insert into akun(password,jabatan) values ('" + data[4] + "','" + data[5] +"')";
        execute(query2);
        return execute(query);
    }

    @Override
    public boolean updateData(String data[]) {
        String query = "update petugas set nama_petugas = '" + data[2] + "',no_HP = '" + data[3] + "',alamat = '" + data[4] + "' where id_petugas = " + data[0] + ";";
        String query2 = "update akun set password = '"+data[5]+"' where id_akun = " +data[1]+ ";";
        for (int i = 4; i < data.length; i++) {
            String string = data[i];
            
        }
       execute(query2);
        return execute(query);
    }

    @Override
    public boolean deleteData(String ID) {
        String query = "Delete From petugas where id_petugas = " + ID + ";";
        return execute(query);
    }
}
