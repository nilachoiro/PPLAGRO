/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author nila
 */
public class Mresep extends ModelMaster {

    public Mresep() throws SQLException {
        con = new koneksi();
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"id_obat", "nama_obat", "indikasi", "bentuk", "isi", "stok", "keterangan"};
        String query = "select * from obat;";
        return getDatatotal(kolom, query);
    }

    public DefaultTableModel getDataCari(String ID) throws SQLException {
       String kolom[] = {"id_obat", "nama_obat", "indikasi", "bentuk", "isi", "stok", "keterangan"};
        String query = "select * from obat where nama_obat='" + ID + "';";
        return getDatatotal(kolom, query);

    }

    public DefaultTableModel getData2(String id) throws SQLException {
        String kolom[] = {"id_pemeriksaan", "id_obat", "nama_obat"};
        String query = "select id_pemeriksaan,o.id_obat,nama_obat from resep r join obat o on(r.id_obat=o.id_obat) where id_pemeriksaan=" + id + ";";
        return getDatatotal(kolom, query);

    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[7];
        String query = "select * from obat where id_obat = " + ID + ";";
        return getDataID(query, data);
    }

    public String[] getDataWithID2(String ID) throws SQLException {
        String data[] = new String[3];
        String query = "select id_pemeriksaan,o.id_obat,nama_obat from resep r join obat o on(r.id_obat=o.id_obat) where id = " + ID + ";";
        return getDataID(query, data);

    }

    public boolean insertRESEP(String pemeriksaan, String ID) {
        String query = "insert into resep (id,id_pemeriksaan,id_obat) values(null,'" + pemeriksaan + "','" + ID + "')";
        return execute(query);
    }

    @Override
    public boolean updateData(String[] data) {
        String query = "update obat set nama_obat = '" + data[1] + "',indikasi = '" + data[2] + "',bentuk = '" + data[3] + "',isi = '" + data[4] + "' where id_obat = " + data[0] + ";";
        return execute(query);
    }

    @Override
    public boolean deleteData(String ID) {
        String query = "Delete From obat where id_obat = " + ID + ";";
        return execute(query);
    }

    @Override
    public boolean insertData(String[] data) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean cetak(String Idperiksa) {
        String query = "select *from resep where id_pemeriksaan = " + Idperiksa + ";";
        return execute(query);
    }

}
