/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author nila
 */
public class Mdokter_rekamedik extends ModelMaster {

    koneksi con;

    public Mdokter_rekamedik() throws SQLException {
        con = new koneksi(); //membuat objek koneksi baru dari kelas koneksi.
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"no_rekamedik", "nama_pasien", "tanggal_lahir", "jenis kelamin", "alamat", "id_pemeriksaan", "tanggal periksa", "keluhan", "diagnosa"};
        String query = "select p.no_rekamedik,nama_pasien,tanggal_lahir,jenkel,alamat,id_pemeriksaan,tgl_periksa,keluhan,diagnosa from pasien p join pemeriksaan pe on(p.no_rekamedik=pe.no_rm);";
        return getDatatotal(kolom, query);
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[9];
        String query = "Select p.no_rekamedik,nama_pasien,tanggal_lahir,jenkel,alamat,id_pemeriksaan,tgl_periksa,keluhan,diagnosa from pasien p join pemeriksaan pe on(p.no_rekamedik=pe.no_rm)where no_rekamedik = " + ID + ";";

        return getDataID(query, data);
    }

    public DefaultTableModel getDataCari(String ID) throws SQLException {
        String kolom[] = {"no_rekamedik", "nama_pasien", "tanggal_lahir", "jenis kelamin", "alamat", "id_pemeriksaan", "tanggal periksa", "keluhan", "diagnosa"};
        String query = "Select p.no_rekamedik,nama_pasien,tanggal_lahir,jenkel,alamat,id_pemeriksaan,tgl_periksa,keluhan,diagnosa from pasien p join pemeriksaan pe on(p.no_rekamedik=pe.no_rm)where no_rekamedik = " + ID + ";";
   return getDatatotal(kolom, query);
    }

    @Override
    public boolean insertData(String[] data) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean updateData(String[] data) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean deleteData(String ID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
