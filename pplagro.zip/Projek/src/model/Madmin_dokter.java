package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Aichi
 */
public class Madmin_dokter extends ModelMaster {

    public Madmin_dokter() throws SQLException {
        con = new koneksi();
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"NIP","ID_akun","nama_dokter", "id_poli", "alamat", "no_hp","password","jabatan"};
        String query = "select NIP,a.id_akun,nama_dokter,id_poli,alamat,no_hp,password,jabatan from dokter d join akun a on(d.id_akun=a.id_akun);";
        return getDatatotal(kolom, query);
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[8];
        String query = "select NIP,a.id_akun,nama_dokter,id_poli,alamat,no_hp,password,jabatan from dokter d join akun a on(d.id_akun=a.id_akun) where NIP = " + ID + ";";
        return data;
    }

    @Override
    public boolean insertData(String data[]) {
        String query = "insert into dokter (NIP,id_akun,nama_dokter,id_poli,alamat,no_hp) values (null,(select MAX(id_akun) from akun order by id_akun ASC),'"+ data[2] + "'," + data[3] + ",'" + data[4] + "','" + data[5] + "')";
        String query2 = "insert into akun(id_akun,password,jabatan) values (null,'" + data[6] + "','" + data[7] +"')";
        execute(query2);
        return execute(query);
    }

    @Override
    public boolean updateData(String data[]) {

        String query = "update dokter set nama_dokter = '" + data[2] + "',id_poli = " + data[3] + ",alamat = '" + data[4] + "',no_hp = '" + data[5] + "' where NIP = " + data[0] + ";";
         String query2 = "update akun set password = '"+data[6]+"' where id_akun = " +data[1]+ ";";
        execute(query2);
         return execute(query);
    }

    @Override
    public boolean deleteData(String ID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
