/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author nila
 */
public class Mdokter_tampilanpemeriksaan extends ModelMaster {
koneksi con;
    public Mdokter_tampilanpemeriksaan() throws SQLException {
        con = new koneksi();
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
             String kolom[] = {"id_pemeriksaan", "no_pemeriksaan", "tgl_periksa","id_dokter","keluhan","diagnosa", "status_pemeriksaan", "id_petugas"};
        String query = "select * from pemeriksaan;";
        return getDatatotal(kolom, query); }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[8];
        String query = "select * from pemeriksaan where id_pemeriksaan = " + ID + ";";
         return getDataID(query, data); }

    @Override
    public boolean insertData(String[] data) {
       String query = "insert into pemeriksaan(id_pemeriksaan,no_rm,tgl_periksa,id_dokter,keluhan,diagnosa,status_pemeriksaan,id_petugas) values (null,"+data[1]+",now(),"+data[3]+","+data[4]+","+data[5]+","+data[6]+","+data[7]+");";
        return execute(query); }

    @Override
    public boolean updateData(String[] data) {
   String query = "update pemeriksaan set id_dokter = " + data[3] + ",keluhan = '" + data[4] + "',diagnosa = '" + data[5] + "' where id_pemeriksaan = " + data[0] + ";";
        return execute(query); 
    }

    @Override
    public boolean deleteData(String ID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
