/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author nila
 */
public class Madmin_obat extends ModelMaster {
 public Madmin_obat() throws SQLException {
        con = new koneksi(); 
 }
    @Override
    public DefaultTableModel getData() throws SQLException {
     String kolom[] = {"id_obat", "nama_obat","indikasi","bentuk","isi"};
        String query = "select * from obat;";
       return getDatatotal(kolom, query);
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
            String data[] = new String[5]; 
            String query = "select * from obat where id_obat = " + ID + ";";
        return getDataID(query, data);
    }

    @Override
    public boolean insertData(String[] data) { 
       String query = "insert into obat (nama_obat,indikasi,bentuk,isi) values('" + data[1] + "','"+ data[2] + "','" + data[3] + "','" + data[4] + "')";
        return execute(query);
       
    }

    @Override
    public boolean updateData(String[] data) {
    String query = "update obat set nama_obat = '" + data[1] + "',indikasi = '" + data[2] + "',bentuk = '" + data[3] + "',isi = '" + data[4] + "' where id_obat = "+data[0]+";";
        return execute(query);
    }

    @Override
    public boolean deleteData(String ID) {
      String query = "Delete From obat where id_obat = "+ID+";";
      return execute(query);
    }
    }
    

