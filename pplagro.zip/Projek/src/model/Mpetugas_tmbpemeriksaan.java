/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author nila
 */
public class Mpetugas_tmbpemeriksaan extends ModelMaster {

    public Mpetugas_tmbpemeriksaan() throws SQLException {
        con = new koneksi(); //membuat objek koneksi baru dari kelas koneksi.
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"id_pemeriksaan", "no_pemeriksaan", "tgl_periksa", "status_pemeriksaan", "id_petugas"};
        String query = "select id_pemeriksaan,no_rm,tgl_periksa,status_pemeriksaan,id_petugas from pemeriksaan;";
        return getDatatotal(kolom, query);
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[5];
        String query = "select id_pemeriksaan,no_rm,tgl_periksa,status_pemeriksaan,id_petugas from pemeriksaan where id_pemeriksaan = " + ID + ";";
         return getDataID(query, data);
    }

    @Override
    public boolean insertData(String[] data) {
     String query = "insert into pemeriksaan(id_pemeriksaan,no_rm,tgl_periksa,status_pemeriksaan,id_petugas) values (null,"+data[1]+",now(),"+data[3]+","+data[4]+");";
        return execute(query); 
    }

    @Override
    public boolean updateData(String[] data) {
    String query = "update pemeriksaan set no_rm = " + data[1] + ",status_pemeriksaan = " + data[3] + ",id_petugas = " + data[4] + " where id_pemeriksaan = " + data[0] + ";";
        return execute(query); }

    @Override
    public boolean deleteData(String ID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
