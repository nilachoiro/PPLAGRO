/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author nila
 */
public class Mpetugas_tmbpasien extends ModelMaster {

    koneksi con;

    public Mpetugas_tmbpasien() throws SQLException {
        con = new koneksi(); //membuat objek koneksi baru dari kelas koneksi.
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"no_rekamedik", "tgl_daftar", "nama_pasien", "tanggal_lahir", "jenkel", "alamat"};
        String query = "select * from pasien;";
        return getDatatotal(kolom, query);
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[6];
        String query = "select * from pasien where no_rekamedik = " + ID + ";";
        return getDataID(query, data);
    }

    @Override
    public boolean insertData(String[] data) {
        String query = "insert into pasien(tgl_daftar,nama_pasien,tanggal_lahir,jenkel,alamat) values (now(),'" + data[2] + "','" + data[3] + "','" + data[4] + "','" + data[5] + "')";
        return execute(query);
    }

    @Override
    public boolean updateData(String[] data) {
        String query = "update pasien set nama_pasien = '" + data[2] + "',tanggal_lahir = '" + data[3] + "',jenkel= '" + data[4] + "',alamat = '" + data[5] + "' where no_rekamedik = " + data[0] + ";";
        return execute(query);
    }

    public DefaultTableModel getDataCari(String ID) throws SQLException {
        String kolom[] = {"no_rekamedik","tgl_daftar","nama_pasien", "tanggal_lahir", "jenis kelamin", "alamat"};
        String query = "Select * from pasien where no_rekamedik = " + ID + ";";
        return getDatatotal(kolom, query);
    }

    @Override
    public boolean deleteData(String ID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
