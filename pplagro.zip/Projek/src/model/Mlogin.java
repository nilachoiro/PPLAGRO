/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.SQLException;
import java.sql.ResultSet;

/**
 *
 * @author nila
 */
public class Mlogin {

    private koneksi con;

    public Mlogin() throws SQLException {
        con = new koneksi();
    }

    public boolean isIdExist(int id) throws SQLException {
        String query = "select id_akun from akun where id_akun = " + id;
        ResultSet hasil = con.getResult(query);
        if (hasil.next()) {
            System.out.println("berhasil");
            return true;
        } else {
            System.out.println("gagal");
            return false;
        }
    }
    public String[] getInfo(int id) throws SQLException{
    String query = "select jabatan from akun where id_akun = " + id;
    String[] data = new String[3];
        ResultSet rs = con.getResult(query);
        if (rs.next()) { // Jika Data dengan ID tersebut Ditemukan.
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1); //memasukkan data yg diperoleh kedalam array
            }
        }
        for (int i = 0; i < data.length; i++) {
            System.out.println(data[i]);
            
        }
        return data;
    }
    public String[] getInfodokter(String id) throws SQLException{
    String query = "select * from dokter where id_akun = " + id;
    String[] data = new String[6];
        ResultSet rs = con.getResult(query);
        if (rs.next()) { // Jika Data dengan ID tersebut Ditemukan.
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1); //memasukkan data yg diperoleh kedalam array
            }
        }
        for (int i = 0; i < data.length; i++) {
            System.out.println(data[i]);
            
        }
        return data;
    }
        public String[] getInfopetugas(String id) throws SQLException{
    String query = "select * from petugas where id_akun = " + id;
    String[] data = new String[5];
        ResultSet rs = con.getResult(query);
        if (rs.next()) { // Jika Data dengan ID tersebut Ditemukan.
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1); //memasukkan data yg diperoleh kedalam array
            }
        }
        for (int i = 0; i < data.length; i++) {
            System.out.println(data[i]);
            
        }
        return data;
    }
            public String[] getInfoadmin(String id) throws SQLException{
    String query = "select * from akun where id_akun = " + id;
    String[] data = new String[3];
        ResultSet rs = con.getResult(query);
        if (rs.next()) { // Jika Data dengan ID tersebut Ditemukan.
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1); //memasukkan data yg diperoleh kedalam array
            }
        }
        for (int i = 0; i < data.length; i++) {
            System.out.println(data[i]);
            
        }
        return data;
    }
   

    public boolean isPasswordValid(int id, String password) throws SQLException {
        String query = "select password from akun where id_akun = " + id;
        ResultSet hasil = con.getResult(query);
        String dbPassword = null;
        if (hasil.next()) {
            dbPassword = hasil.getString(1);
        }
        if (dbPassword.equals(password)) {
            return true;
        } else {
            return false;
        }
    }

    public String getJabatan(int id) throws SQLException {
        String query = "select jabatan from akun where id_akun = " + id;
        ResultSet hasil = con.getResult(query);
        String jabatan = null;
        if (hasil.next()) {
            jabatan = hasil.getString(1);
        }
        return jabatan;
    }
}
