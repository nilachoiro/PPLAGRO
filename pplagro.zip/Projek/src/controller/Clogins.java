/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Madmin_petugas;
import model.Mdokter_rekamedik;
import model.Mdokter_tampilanpemeriksaan;
import model.Mlogin;
import model.Mpetugas_tmbpasien;
import model.Mpetugas_tmbpemeriksaan;
import model.Mresep;
import view.admin_tmpPetugas;
import view.dokter_rekamedik;
import view.dokter_tampilanpemeriksaan;
import view.logins;
import view.petugas_tmbpasien;
import view.petugas_tmbpemeriksaan;
import view.tampilanresep;

/**
 *
 * @author nila
 */
public class Clogins {

    public logins view;
    public Mlogin model;
    public static String[] dokter = new String[6];
    public static String[] petugas = new String[5];
    public static String[] admin = new String[3];

    public Clogins(logins view, Mlogin model) {
        this.view = view;
        this.model = model;
        view.setVisible(true);

        view.addLoginListener(new loginListener());
    }

    private class loginListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (model.isIdExist(view.getId())) {
                    if (model.isPasswordValid(view.getId(), view.getPassword())) {
                        switch (model.getJabatan(view.getId())) {
                            case "admin":
                                admin = model.getInfoadmin(view.getId() + "");
                                new Cadmin_petugas(new admin_tmpPetugas(), new Madmin_petugas());
                                // String[] data=model.getInfo(view.getId());
                                break;
                            case "petugas":
                                petugas = model.getInfopetugas(view.getId() + "");
                                //new Cpetugas_tmbpemeriksaan(new petugas_tmbpemeriksaan(), new Mpetugas_tmbpemeriksaan());
                                new Cpetugas_tmbpasien(new petugas_tmbpasien(), new Mpetugas_tmbpasien());
                                break;
                            case "dokter":
                                dokter = model.getInfodokter(view.getId() + "");
                                //  new Cdokter_rekamedik(new dokter_rekamedik(), new Mdokter_rekamedik());
                                new Cdokter_tampilanpemeriksaan(new dokter_tampilanpemeriksaan(), new Mdokter_tampilanpemeriksaan());
                                // new Cresep(new tampilanresep(), new Mresep());
                                break;

                        }
                        view.dispose();
                    } else {
                        view.message("Password salah");
                    }
                } else {
                    view.message("ID tidak terdaftar");
                }
            } catch (Exception ex) {
            }
        }
    }

}
