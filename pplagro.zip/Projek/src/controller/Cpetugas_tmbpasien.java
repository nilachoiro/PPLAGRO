/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

/**
 *
 * @author nila
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Mdokter_tampilanpemeriksaan;
import model.Mpetugas_tmbpasien;
import model.Mpetugas_tmbpemeriksaan;
import view.dokter_tampilanpemeriksaan;
import view.petugas_tmbpasien;
import view.petugas_tmbpemeriksaan;

public class Cpetugas_tmbpasien {

    petugas_tmbpasien view;
    Mpetugas_tmbpasien model;

    public Cpetugas_tmbpasien(petugas_tmbpasien view, Mpetugas_tmbpasien model) throws SQLException {
        this.view = view;
        this.model = model;

        this.view.setTableModel(this.model.getData());

        this.view.simpanClick(new Cpetugas_tmbpasien.simpanListener());
        this.view.updateClick(new Cpetugas_tmbpasien.updateListener());
        this.view.cariClick(new cariListener());
        view.pemeriksaanClick(new pemeriksaanListener());
        this.view.setVisible(true);
    }

    private class cariListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getnorm() == null) {
                view.showMessagePane("Masukkan no rekamedik yang akan dicari");

            } else {
                try {

                    view.setTableModel(model.getDataCari(view.getnorm()));

                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");

                }

            }

        }
    }

    private class pemeriksaanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new Cpetugas_tmbpemeriksaan(new petugas_tmbpemeriksaan(), new Mpetugas_tmbpemeriksaan());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_petugas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class simpanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSaveButtonText().equalsIgnoreCase("simpan")) {
                try {
                    if (model.insertData(view.getData())) {
                        view.showMessagePane("Data Berhasil Di Simpan");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Data Gagal Di Simpan");
                    }
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            } else {
                try {
                    if (model.updateData(view.getData())) {
                        view.showMessagePane("Data Berhasil Di Simpan");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Data Gagal Di Simpan");
                    }

//                    view.setName("");
//                    view.settgllahir("");
//                    view.set("");
//                    view.setFieldHP("");
                    view.setSaveButtonText("Simpan");
                    view.setFieldIDEditable(true);
                    view.setUpdateEnable(true);
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }

    private class updateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSelectedRow() == -1) {
                view.showMessagePane("Pilih Dulu Gan");
            } else {
                try {
                    String[] data = model.getDataWithID(view.getIdFromTable());
                    view.setUpdateEnable(false); // agar tombol update tidak bisa diakses
                    view.setFieldIDEditable(false);
                    view.setSaveButtonText("Update Data");
                    view.setFieldID(data[0]);
                    view.settgldaftar(data[1]);
                    view.setFieldnamapasin(data[2]);
                    view.settgllahir(data[3]);
                    view.setjenkel(data[4]);
                    view.setAlamat(data[5]);

                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }
    }
}
