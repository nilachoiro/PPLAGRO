package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Madmin_obat;
import model.Madmin_dokter;
import model.Madmin_petugas;
import view.admin_tmpObat;
import view.admin_tmpPetugas;
import view.admin_tmpdokter;

/**
 *
 * @author Aichi
 */
public class Cadmin_obat {

    admin_tmpObat view;
    Madmin_obat model;

    public Cadmin_obat(admin_tmpObat view, Madmin_obat model) throws SQLException {
        this.view = view;
        this.model = model;

        this.view.setTableModel(this.model.getData());
        this.view.simpanClick(new Cadmin_obat.simpanListener());
        this.view.updateClick(new Cadmin_obat.updateListener());
        this.view.petugasClick(new petugasListener());
         this.view.dokterClick(new dokterListener());
        this.view.setVisible(true);
    }

    private class simpanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSaveButtonText().equalsIgnoreCase("simpan")) {
                try {
                    if (model.insertData(view.getData())) {
                        view.showMessagePane("Data Berhasil Di Simpan");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Data Gagal Di Simpan");
                    }
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            } else {
                try {
                    if (model.updateData(view.getData())) {
                        view.showMessagePane("Data Berhasil Di Simpan");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Data Gagal Di Simpan");
                    }

                    view.setFieldnamaObat("");
                    view.setIndikasi("");
                    view.setbentukt("");
                    view.setIsi("");

                    view.setSaveButtonText("Simpan");
                    view.setFieldIDEditable(true);
                    view.setUpdateEnable(true);
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }

    private class updateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSelectedRow() == -1) {
                view.showMessagePane("Pilih Dulu Gan");
            } else {
                try {
                    String[] data = model.getDataWithID(view.getIdFromTable());
                    view.setUpdateEnable(false);
                    view.setFieldIDEditable(false);
                    view.setSaveButtonText("Update Data");
                    view.setFieldID(data[0]);
                    view.setFieldnamaObat(data[1]);
                    view.setIndikasi(data[2]);
                    view.setbentukt(data[3]);
                    view.setIsi(data[4]);

                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }
    }
    private class deleteListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSelectedRow() == -1) { 
                view.showMessagePane("Pilih Baris yang akan dihapus");
            } else if (view.showOptionPane("Apakah Anda Yakin Akan Menghapus Data ?") == JOptionPane.YES_OPTION) { //Jika user memilih Ya pada OptionPane
             try {
                    if (model.deleteData(view.getIdFromTable())) {
                        view.showMessagePane("Data Berhasil Di Hapus");
                        view.setTableModel(model.getData()); 
                    } else {
                        view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                    }
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }
    private class petugasListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new Cadmin_petugas(new admin_tmpPetugas(), new Madmin_petugas());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_obat.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    
    }
        private class dokterListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            try {
                System.out.println("tampilkannnnn");
                view.dispose();
                new Cadmin_dokter(new admin_tmpdokter(), new Madmin_dokter());
            } catch (SQLException ex) {
//                Logger.getLogger(Cadmin_obat.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    
    }
}
