/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Madmin_dokter;
import model.Madmin_obat;
import model.Madmin_petugas;
import view.admin_tmpObat;
import view.admin_tmpPetugas;
import view.admin_tmpdokter;

/**
 *
 * @author nila
 */
public class Cadmin_petugas {

    admin_tmpPetugas view;
    Madmin_petugas model;

    public Cadmin_petugas(admin_tmpPetugas view, Madmin_petugas model) throws SQLException {
        this.view = view;
        this.model = model;

        this.view.setTableModel(this.model.getData());

        this.view.simpanClick(new simpanListener());
        this.view.updateClick(new updateListener());
        this.view.dokterClick(new dokterListener());
        this.view.obatClick(new obatListener());

        this.view.setVisible(true);
    }

    private class simpanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSaveButtonText().equalsIgnoreCase("simpan")) {
                try {
                    if (model.insertData(view.getData())) {
                        view.showMessagePane("Data Berhasil Di Simpan");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Data Gagal Di Simpan");
                    }
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            } else {
                try {
                    if (model.updateData(view.getData())) {
                        view.showMessagePane("Data Berhasil Di Simpan");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Data Gagal Di Simpan");
                    }
                    view.setFieldID("");
                    view.setIDakun("");
                    view.setFieldnamaPetugas("");
                    view.setAlamat("");
                    view.setnoHP("");
                    view.setPassword("");
                    view.setJabatan("");

                    view.setSaveButtonText("Simpan");
                    view.setFieldIDEditable(true);
                    view.setUpdateEnable(true);
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }

    private class updateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSelectedRow() == -1) {
                view.showMessagePane("Pilih Dulu Gan");
            } else {
                try {
                    String[] data = model.getDataWithID(view.getIdFromTable());
                    view.setUpdateEnable(false); // agar tombol update tidak bisa diakses
                    view.setFieldIDEditable(false);
                    view.setSaveButtonText("Update Data");
                    view.setFieldID(data[0]);
                    view.setIDakun(data[1]);
                    view.setFieldnamaPetugas(data[2]);
                    view.setnoHP(data[3]);
                    view.setAlamat(data[4]);
                    view.setPassword(data[5]);
                    view.setJabatan(data[6]);

                    for (int i = 0; i < data.length; i++) {
                        String string = data[i];
                        System.out.println(i + "." + data[i]);

                    }

                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }
    }

    private class dokterListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                 view.dispose();
                new Cadmin_dokter(new admin_tmpdokter(), new Madmin_dokter());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_petugas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
        private class obatListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                 view.dispose();
                new Cadmin_obat(new admin_tmpObat(), new Madmin_obat());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_petugas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
