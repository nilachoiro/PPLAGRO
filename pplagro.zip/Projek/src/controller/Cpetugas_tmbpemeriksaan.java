/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Mpetugas_tmbpasien;
import model.Mpetugas_tmbpemeriksaan;
import view.petugas_tmbpasien;
import view.petugas_tmbpemeriksaan;

/**
 *
 * @author nila
 */
public class Cpetugas_tmbpemeriksaan {

    petugas_tmbpemeriksaan view;
    Mpetugas_tmbpemeriksaan model;

    public Cpetugas_tmbpemeriksaan(petugas_tmbpemeriksaan view, Mpetugas_tmbpemeriksaan model) throws SQLException {
        this.view = view;
        this.model = model;

        this.view.setTableModel(this.model.getData());
        this.view.setIDpetugas(Clogins.petugas[0]);
        this.view.simpanClick(new simpanListener());
        this.view.updateClick(new updateListener());
        view.PasienClick(new pasienListener());
        this.view.setVisible(true);
    }

    private class simpanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSaveButtonText().equalsIgnoreCase("simpan")) {
                try {
                    if (model.insertData(view.getData())) {
                        view.showMessagePane("Data Berhasil Di Simpan");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Data Gagal Di Simpan");
                    }
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            } else {
                try {
                    if (model.updateData(view.getData())) {
                        view.showMessagePane("Data Berhasil Di Simpan");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Data Gagal Di Simpan");
                    }
                    view.setFieldID("");
                    view.setNorm("");
                    view.settglperiksa("");
                    view.setstatus("");
                    view.setIDpetugas("");

                    view.setSaveButtonText("Simpan");
                    view.setFieldIDEditable(true);
                    view.setUpdateEnable(true);
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }

    private class updateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSelectedRow() == -1) {
                view.showMessagePane("Pilih baris yang akan diubah");
            } else {
                try {
                    String[] data = model.getDataWithID(view.getIdFromTable());
                    view.setUpdateEnable(false); // agar tombol update tidak bisa diakses
                    view.setFieldIDEditable(false);
                    view.setSaveButtonText("Update Data");
                    view.setFieldID(data[0]);
                    view.setNorm(data[1]);
                    view.settglperiksa(data[2]);
                    view.setstatus(data[3]);
                    view.setIDpetugas(data[4]);

                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }
    }

    private class pasienListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new Cpetugas_tmbpasien(new petugas_tmbpasien(), new Mpetugas_tmbpasien());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_petugas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
