/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Madmin_dokter;
import model.Mdokter_rekamedik;
import model.Mdokter_tampilanpemeriksaan;
import model.Mresep;
import view.admin_tmpdokter;
import view.dokter_rekamedik;
import view.dokter_tampilanpemeriksaan;
import view.tampilanresep;

/**
 *
 * @author nila
 */
public class Cdokter_rekamedik {

    dokter_rekamedik view;
    Mdokter_rekamedik model;

    public Cdokter_rekamedik(dokter_rekamedik view, Mdokter_rekamedik model) throws SQLException {
        this.view = view;
        this.model = model;

        this.view.setTableModel(this.model.getData());
        this.view.setVisible(true);
        this.view.cariClick(new Cdokter_rekamedik.cariListener());
        this.view.pemeriksaanClick(new pemeriksaanListener());
        this.view.resepClick(new resepListener());

    }

    private class cariListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getnorm() == null) {
                view.showMessagePane("Masukkan no rekamedik yang akan dicari");

            } else {
                try {

                    view.setTableModel(model.getDataCari(view.getnorm()));

                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");

                }

            }

        }

    }

    private class resepListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new Cresep(new tampilanresep(), new Mresep());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_petugas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class pemeriksaanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new Cdokter_tampilanpemeriksaan(new dokter_tampilanpemeriksaan(), new Mdokter_tampilanpemeriksaan());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_petugas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
