/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Mdokter_rekamedik;
import model.Mdokter_tampilanpemeriksaan;
import model.Mresep;
import view.dokter_rekamedik;
import view.dokter_tampilanpemeriksaan;
import view.petugas_tmbpemeriksaan;
import view.tampilanresep;

/**
 *
 * @author nila
 */
public class Cdokter_tampilanpemeriksaan {

    dokter_tampilanpemeriksaan view;
    Mdokter_tampilanpemeriksaan model;
    Clogins clogin;

    public Cdokter_tampilanpemeriksaan(dokter_tampilanpemeriksaan view, Mdokter_tampilanpemeriksaan model) throws SQLException {
        this.view = view;
        this.model = model;

        this.view.setTableModel(this.model.getData());
        this.view.simpanClick(new simpanListener());
        this.view.updateClick(new updateListener());
        this.view.setnamadktr(clogin.dokter[2]);
        this.view.setIDdokter(clogin.dokter[0]);
        view.rekamClick(new rekamListener());
        view.resepClick(new resepListener());
        this.view.setVisible(true);
    }

    private class simpanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            try {
                if (model.updateData(view.getData())) {
                    view.showMessagePane("Data Berhasil Di Simpan");
                    view.setTableModel(model.getData());
                    view.setsaveEnable(false);
                } else {
                    view.showMessagePane("Data Gagal Di Simpan");
                }
                view.setFieldID("");
                view.setNorm("");
                view.settglperiksa("");
                view.setIDdokter("");
                view.setkeluhan("");
                view.setdiagnosa("");
                view.setstatus("");
                view.setIDpetugas("");

                view.setSaveButtonText("Simpan");
                view.setFieldIDEditable(true);
                view.setUpdateEnable(true);
            } catch (SQLException ex) {
                view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
            }
        }

    }

    private class updateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSelectedRow() == -1) {
                view.showMessagePane("Pilih baris yang akan diubah");
            } else {
                try {
                    String[] data = model.getDataWithID(view.getIdFromTable());
                    view.setUpdateEnable(false); // agar tombol update tidak bisa diakses
                    view.setFieldIDEditable(false);
                    view.setFieldID(data[0]);
                    view.setNorm(data[1]);
                    view.settglperiksa(data[2]);
                    view.setIDdokter(data[3]);
                    view.setkeluhan(data[4]);
                    view.setdiagnosa(data[5]);
                    view.setstatus(data[6]);
                    view.setIDpetugas(data[7]);
                    view.setsaveEnable(true);
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }

            }

        }
    }

    private class rekamListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new Cdokter_rekamedik(new dokter_rekamedik(), new Mdokter_rekamedik());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_petugas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class resepListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new Cresep(new tampilanresep(), new Mresep());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_petugas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
