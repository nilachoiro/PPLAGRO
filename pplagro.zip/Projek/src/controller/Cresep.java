package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Madmin_obat;
import model.Mdokter_rekamedik;
import model.Mdokter_tampilanpemeriksaan;
import model.Mresep;
import view.dokter_rekamedik;
import view.dokter_tampilanpemeriksaan;
import view.tampilanresep;

/**
 *
 * @author Aichi
 */
public class Cresep {

    tampilanresep view;
    Mresep model;

    public Cresep(tampilanresep view, Mresep model) throws SQLException {
        this.view = view;
        this.model = model;

        this.view.setTableModel(this.model.getData());

        this.view.updateClick(new Cresep.updateListener());
        this.view.cariClick(new Cresep.cariListener());
        this.view.pemeriksaanClick(new pemeriksaanListener());
        this.view.rekamClick(new rekamListener());
        this.view.setVisible(true);
    }

    public class cariListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getCariObat() == null) {
                view.showMessagePane("Masukkan no rekamedik yang akan dicari");

            } else {
                try {

                    view.setTableModel(model.getDataCari(view.getCariObat()));

                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");

                }

            }
        }
    }

    private class simpanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSaveButtonText().equalsIgnoreCase("simpan")) {
                try {
                    if (model.insertData(view.getData())) {
                        view.showMessagePane("Data Berhasil Di Simpan");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Data Gagal Di Simpan");
                    }
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            } else {
                try {

                    if (model.updateData(view.getData())) {
                        view.showMessagePane("Data Berhasil Di Simpan");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Data Gagal Di Simpan");
                    }

                    view.setFieldnamaObat("");
                    view.setIndikasi("");
                    view.setbentukt("");
                    view.setIsi("");
                    view.setketerangan("");
                    view.setSaveButtonText("Tambah");
                    view.setUpdateEnable(true);
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }

    private class updateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSelectedRow() == -1) {
                view.showMessagePane("Pilih Dulu Gan");
            } else {
                try {
                    String[] data = model.getDataWithID(view.getIdFromTable());
                    view.setSaveButtonText("Tambah lagi");
                    view.setFieldID(data[0]);
                    view.setFieldnamaObat(data[1]);
                    view.setIndikasi(data[2]);
                    view.setbentukt(data[3]);
                    view.setIsi(data[4]);
                    view.setketerangan(data[6]);
                    model.insertRESEP(view.getIDpemeriksaan(), data[0]);

                    view.setTableModel2(model.getData2(view.getIDpemeriksaan()));

                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }
    }

    private class deleteListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSelectedRow() == -1) {
                view.showMessagePane("Pilih Baris yang akan dihapus");
            } else if (view.showOptionPane("Apakah Anda Yakin Akan Menghapus Data ?") == JOptionPane.YES_OPTION) { //Jika user memilih Ya pada OptionPane
                try {
                    if (model.deleteData(view.getIdFromTable())) {
                        view.showMessagePane("Data Berhasil Di Hapus");
                        view.setTableModel(model.getData());
                    } else {
                        view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                    }
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }

    private class pemeriksaanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new Cdokter_tampilanpemeriksaan(new dokter_tampilanpemeriksaan(), new Mdokter_tampilanpemeriksaan());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_petugas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class rekamListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.dispose();
                new Cdokter_rekamedik(new dokter_rekamedik(), new Mdokter_rekamedik());
            } catch (SQLException ex) {
                Logger.getLogger(Cadmin_petugas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class selesaiListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

        }

    }

}
