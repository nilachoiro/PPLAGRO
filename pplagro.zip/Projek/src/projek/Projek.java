/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projek;

import controller.Cadmin_dokter;
import controller.Cadmin_obat;
import controller.Cadmin_petugas;
import controller.Clogins;
import java.sql.SQLException;

import model.Mlogin;

import view.logins;

/**
 *
 * @author Aichi
 */
public class Projek {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {

        new Clogins(new logins(), new Mlogin());
//new Clogin(new login_form2(), new Mlogin());
//new Cadmin_petugas(new admin_tmpPetugas(), new Madmin_petugas());

    }

}
