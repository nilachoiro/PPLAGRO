/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Aichi
 */
public class petugas_tmbpasien extends javax.swing.JFrame {

    /**
     * Creates new form tampilan_petugas
     */
    public petugas_tmbpasien() {
        initComponents();
    }
 public void setTableModel(DefaultTableModel table) {
        this.TabelPasien.setModel(table);
    }

    public int getSelectedRow() {
        return this.TabelPasien.getSelectedRow();
    }
        public String getnorm() {
        return this.txtrm.getText();
    }
    
    public void cariClick(ActionListener action) {
        this.cari.addActionListener(action);
    }

    public String getIdFromTable() {
        return this.TabelPasien.getValueAt(this.getSelectedRow(), 0).toString(); // 0 adalah index kolom yang dimabil
    }

    public String[] getData() {
        String data[] = new String[6];
        data[0] = this.id.getText();
        data[1] = this.tgl_daftar.getText();
        data[2] = this.namapasien.getText();
        data[3] = this.tanggallahir.getText();
        data[4] = this.jeniskelamin.getSelectedItem()+"";
        data[5] = this.alamat.getText();
        return data;
    }

    public void setFieldID(String text) {
 this.id.setText(text);
    }
    

    public void setFieldnamapasin(String text) {
        this.namapasien.setText(text);
    }
     public void settgldaftar(String text) {
        this.tgl_daftar.setText(text);
    }

    public void settgllahir(String text) {
        this.tanggallahir.setText(text);
    }
    public void setjenkel(String text){
        this.jeniskelamin.setSelectedIndex(text.indexOf(text));
    }

    public void setAlamat(String text) {
        this.alamat.setText(text);
    }

   public void setFieldIDEditable(boolean editable) {
          
    }

    //untuk mengatur, apakah tombol update bisa dipakai atau tidak.
    public void setUpdateEnable(boolean enable) {
        this.update.setEnabled(enable);
    }

    //untuk mengambil text pada tombol simpan
    public String getSaveButtonText() {
        return this.simpan.getText();
    }

    //untuk mengatur text pada tombol simpan
    public void setSaveButtonText(String text) {
        this.simpan.setText(text);
    }

    public void simpanClick(ActionListener action) {
        this.simpan.addActionListener(action);
    }
 public void pemeriksaanClick(ActionListener action) {
        this.pemeriksaan.addActionListener(action);
    }
    public void updateClick(ActionListener action) {
        this.update.addActionListener(action);
    }


    public void showMessagePane(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public int showOptionPane(String message) {
        return JOptionPane.showConfirmDialog(this, message, null, JOptionPane.YES_NO_OPTION);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        txtrm = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cari = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelPasien = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        simpan = new javax.swing.JButton();
        update = new javax.swing.JButton();
        namapasien = new javax.swing.JTextField();
        tanggallahir = new javax.swing.JTextField();
        jeniskelamin = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        alamat = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        tgl_daftar = new javax.swing.JLabel();
        id = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        pemeriksaan = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Minion Pro Cond", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Pendaftaran Pasien");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 170, 30));
        getContentPane().add(txtrm, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 220, -1));

        jLabel3.setText("Masukkan no rm");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 124, 120, 20));

        cari.setText("cari");
        getContentPane().add(cari, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 100, -1, -1));

        TabelPasien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(TabelPasien);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 760, 250));

        jLabel6.setText("Tanggal lahir             :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 480, 120, -1));

        jLabel7.setText("Nama Pasien             :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 120, -1));

        jLabel4.setText("Jenis Kelamin            :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 410, 120, -1));

        jLabel8.setText("Alamat                      :");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 450, 120, -1));

        simpan.setText("Simpan");
        getContentPane().add(simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 410, -1, -1));

        update.setText("Update");
        getContentPane().add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 440, -1, -1));
        getContentPane().add(namapasien, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 450, 180, -1));
        getContentPane().add(tanggallahir, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 480, 180, -1));

        jeniskelamin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "L", "P" }));
        getContentPane().add(jeniskelamin, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 410, 60, -1));

        alamat.setColumns(20);
        alamat.setRows(5);
        jScrollPane2.setViewportView(alamat);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 450, 200, 90));

        jLabel5.setText("Tanggal daftar         :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 130, -1));
        getContentPane().add(tgl_daftar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 510, 180, 20));

        id.setText("tes");
        getContentPane().add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 420, 120, 20));

        jLabel9.setText("No Rekamedis           :      ");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, 140, -1));

        pemeriksaan.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        pemeriksaan.setForeground(new java.awt.Color(0, 51, 255));
        pemeriksaan.setText("Pemeriksaan");
        getContentPane().add(pemeriksaan, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, -1, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/petugas.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(petugas_tmbpasien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(petugas_tmbpasien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(petugas_tmbpasien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(petugas_tmbpasien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new petugas_tmbpasien().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TabelPasien;
    private javax.swing.JTextArea alamat;
    private javax.swing.JButton cari;
    private javax.swing.JLabel id;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JComboBox<String> jeniskelamin;
    private javax.swing.JTextField namapasien;
    private javax.swing.JButton pemeriksaan;
    private javax.swing.JButton simpan;
    private javax.swing.JTextField tanggallahir;
    private javax.swing.JLabel tgl_daftar;
    private javax.swing.JTextField txtrm;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
