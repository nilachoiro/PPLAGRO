/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.Cadmin_dokter;
import controller.Cadmin_petugas;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Madmin_petugas;
import model.Madmin_dokter;

/**
 *
 * @author Aichi
 */
public class admin_tmpObat extends javax.swing.JFrame {

    public admin_tmpObat() {
        initComponents();
    }

    public void setTableModel(DefaultTableModel table) {
        this.tabelObat.setModel(table);
    }

    public int getSelectedRow() {
        return this.tabelObat.getSelectedRow();
    }

    public String getIdFromTable() {
        return this.tabelObat.getValueAt(this.getSelectedRow(), 0).toString(); // 0 adalah index kolom yang dimabil
    }

    public String[] getData() {
        String data[] = new String[5];
        data[0] = this.id.getText();
        data[1] = this.namaObat.getText();
        data[2] = this.indikasi.getText();
        data[3] = this.bentuk.getText();
        data[4] = this.isi.getText();
        return data;
    }

    public void setFieldID(String text) {
        this.id.setText(text);
    }

    public void setFieldnamaObat(String text) {
        this.namaObat.setText(text);
    }

    public void setIndikasi(String text) {
        this.indikasi.setText(text);
    }
    public void setbentukt(String text) {
        this.bentuk.setText(text);
    }

    public void setIsi(String text) {
        this.isi.setText(text);
    }

    public void setFieldIDEditable(boolean editable) {
        this.id.setEditable(editable);
    }

    //untuk mengatur, apakah tombol update bisa dipakai atau tidak.
    public void setUpdateEnable(boolean enable) {
        this.update.setEnabled(enable);
    }

    //untuk mengambil text pada tombol simpan
    public String getSaveButtonText() {
        return this.simpan.getText();
    }

    //untuk mengatur text pada tombol simpan
     public void setSaveButtonText(String text) {
        this.simpan.setText(text);
    }
    public void petugasClick(ActionListener action) {
        this.btnpetugas.addActionListener(action);
    }
     public void dokterClick(ActionListener action) {
        this.dokter.addActionListener(action);
    }
      public void logoutClick(ActionListener action) {
        this.logout.addActionListener(action);
    }

    public void simpanClick(ActionListener action) {
        this.simpan.addActionListener(action);
    }

    public void updateClick(ActionListener action) {
        this.update.addActionListener(action);
    }


    public void showMessagePane(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public int showOptionPane(String message) {
        return JOptionPane.showConfirmDialog(this, message, null, JOptionPane.YES_NO_OPTION);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnpetugas = new javax.swing.JButton();
        dokter = new javax.swing.JButton();
        obat = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelObat = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        namaObat = new javax.swing.JTextField();
        indikasi = new javax.swing.JTextField();
        id = new javax.swing.JTextField();
        simpan = new javax.swing.JButton();
        update = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        logout = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        bentuk = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        isi = new javax.swing.JTextField();
        petugas = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnpetugas.setText("Petugas");
        getContentPane().add(btnpetugas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 90, -1));

        dokter.setText("Dokter");
        getContentPane().add(dokter, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 80, -1));

        obat.setBackground(new java.awt.Color(0, 153, 204));
        obat.setText("Obat");
        getContentPane().add(obat, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 70, 80, -1));

        tabelObat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabelObat);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 640, 470));

        jLabel2.setText("Nama Obat :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 180, 80, -1));

        jLabel3.setText("Indikasi :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 230, -1, -1));
        getContentPane().add(namaObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 200, 130, -1));
        getContentPane().add(indikasi, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 250, 130, -1));

        id.setEditable(false);
        getContentPane().add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 150, 130, -1));

        simpan.setText("Simpan");
        getContentPane().add(simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 450, 130, -1));

        update.setText("update");
        getContentPane().add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 410, 130, -1));

        jLabel7.setText("ID Obat :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 130, 90, -1));

        logout.setText("Logout");
        getContentPane().add(logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 80, -1));

        jLabel4.setText("Bentuk :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 280, -1, -1));
        getContentPane().add(bentuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 300, 130, -1));

        jLabel5.setText("Isi :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 330, -1, -1));
        getContentPane().add(isi, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 350, 130, -1));

        petugas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/admin.jpg"))); // NOI18N
        getContentPane().add(petugas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin_tmpObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin_tmpObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin_tmpObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin_tmpObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin_tmpObat().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bentuk;
    private javax.swing.JButton btnpetugas;
    private javax.swing.JButton dokter;
    private javax.swing.JTextField id;
    private javax.swing.JTextField indikasi;
    private javax.swing.JTextField isi;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logout;
    private javax.swing.JTextField namaObat;
    private javax.swing.JButton obat;
    private javax.swing.JLabel petugas;
    private javax.swing.JButton simpan;
    private javax.swing.JTable tabelObat;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
