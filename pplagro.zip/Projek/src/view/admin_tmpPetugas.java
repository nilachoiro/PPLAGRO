/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Aichi
 */
public class admin_tmpPetugas extends javax.swing.JFrame {

    public admin_tmpPetugas() {
        initComponents();
    }

    public void setTableModel(DefaultTableModel table) {
        this.tabelpetugas.setModel(table);
    }

    public int getSelectedRow() {
        return this.tabelpetugas.getSelectedRow();
    }

    public String getIdFromTable() {
        return this.tabelpetugas.getValueAt(this.getSelectedRow(), 0).toString(); // 0 adalah index kolom yang dimabil
    }

    public String[] getData() {
        String data[] = new String[7];
        data[0] = this.id.getText();
        data[1] = this.id_akun.getText();
        data[2] = this.namaPetugas.getText();
        data[3] = this.noHP.getText();
        data[4] = this.Alamat.getText();
        data[5] = this.password.getText();
        data[6] = this.jabatan.getText();

        return data;
    }

    public void setFieldID(String text) {
        this.id.setText(text);
    }

    public void setFieldnamaPetugas(String text) {
        this.namaPetugas.setText(text);
    }

    public void setnoHP(String text) {
        this.noHP.setText(text);
    }

    public void setAlamat(String text) {
        this.Alamat.setText(text);
    }

    public void setPassword(String text) {
        this.password.setText(text);
    }

    public void setJabatan(String text) {
        this.jabatan.setText("petugas");
    }

    public void setIDakun(String text) {
        this.id_akun.setText(text);
    }

    public void setFieldIDEditable(boolean editable) {
        this.id.setEditable(editable);
    }

    //untuk mengatur, apakah tombol update bisa dipakai atau tidak.
    public void setUpdateEnable(boolean enable) {
        this.update.setEnabled(enable);
    }

    //untuk mengambil text pada tombol simpan
    public String getSaveButtonText() {
        return this.simpan.getText();
    }

    //untuk mengatur text pada tombol simpan
    public void setSaveButtonText(String text) {
        this.simpan.setText(text);
    }

    public void dokterClick(ActionListener action) {
        this.dokter.addActionListener(action);
    }

    public void obatClick(ActionListener action) {
        this.obat.addActionListener(action);
    }

    public void simpanClick(ActionListener action) {
        this.simpan.addActionListener(action);
    }

    public void updateClick(ActionListener action) {
        this.update.addActionListener(action);
    }


    public void deleteClick(ActionListener action) {
        this.delete.addActionListener(action);
    }
    //untuk menampilkan JOptionPane Information Message

    public void showMessagePane(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public int showOptionPane(String message) {
        return JOptionPane.showConfirmDialog(this, message, null, JOptionPane.YES_NO_OPTION);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        petugas = new javax.swing.JButton();
        dokter = new javax.swing.JButton();
        obat = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        namaPetugas = new javax.swing.JTextField();
        noHP = new javax.swing.JTextField();
        id = new javax.swing.JTextField();
        simpan = new javax.swing.JButton();
        update = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        Alamat = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        password = new javax.swing.JTextField();
        jabatan = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelpetugas = new javax.swing.JTable();
        id_akun = new javax.swing.JLabel();
        back = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        petugas.setBackground(new java.awt.Color(0, 204, 204));
        petugas.setText("Petugas");
        petugas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                petugasActionPerformed(evt);
            }
        });
        getContentPane().add(petugas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 90, -1));

        dokter.setText("Dokter");
        getContentPane().add(dokter, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 80, -1));

        obat.setText("Obat");
        getContentPane().add(obat, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 70, 80, -1));

        jLabel2.setText("Nama Petugas :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 180, 140, -1));

        jLabel3.setText("No Hp :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 230, -1, -1));
        getContentPane().add(namaPetugas, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 200, 130, -1));
        getContentPane().add(noHP, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 250, 130, -1));

        id.setEditable(false);
        getContentPane().add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 150, 130, -1));

        simpan.setText("Simpan");
        getContentPane().add(simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 510, 130, -1));

        update.setText("update");
        getContentPane().add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 480, 130, -1));

        jLabel7.setText("ID Petugas :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 130, 90, -1));

        jButton5.setText("Logout");
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 80, -1));

        delete.setText("Delete");
        getContentPane().add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 540, 130, -1));

        jLabel4.setText("Alamat :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 280, -1, -1));
        getContentPane().add(Alamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 300, 130, -1));

        jLabel5.setText("Password :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 330, -1, -1));

        jLabel6.setText("Jabatan :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 380, -1, -1));
        getContentPane().add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 350, 130, -1));

        jabatan.setText("Petugas");
        getContentPane().add(jabatan, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 400, 70, -1));

        tabelpetugas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "id_petugas", "id_akun", "nama_petugas", "no_hp", "alamat", "password", "jabatan"
            }
        ));
        jScrollPane2.setViewportView(tabelpetugas);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 640, 470));
        getContentPane().add(id_akun, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 420, 40, 20));

        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/admin.jpg"))); // NOI18N
        getContentPane().add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void petugasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_petugasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_petugasActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin_tmpPetugas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin_tmpPetugas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin_tmpPetugas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin_tmpPetugas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin_tmpPetugas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Alamat;
    private javax.swing.JLabel back;
    private javax.swing.JButton delete;
    private javax.swing.JButton dokter;
    private javax.swing.JTextField id;
    private javax.swing.JLabel id_akun;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel jabatan;
    private javax.swing.JTextField namaPetugas;
    private javax.swing.JTextField noHP;
    private javax.swing.JButton obat;
    private javax.swing.JTextField password;
    private javax.swing.JButton petugas;
    private javax.swing.JButton simpan;
    private javax.swing.JTable tabelpetugas;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
